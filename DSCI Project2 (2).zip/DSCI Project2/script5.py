# -*- coding: utf-8 -*-
"""
Created on Sat Apr 23 14:21:08 2022

@author: FINDLEYJD19
"""

from pyspark.sql import SparkSession
from pyspark.sql.functions import sum, col, max

spark = SparkSession.builder.appName("AgeApp").getOrCreate()
spark.sparkContext.setLogLevel('WARN')
                               
dfOrderSample = spark.read.csv(r"C:\Users\FindleyJD19\Downloads\proj2_data(1)\proj2_data\orders_sample.csv", header=True)
dfProductSample = spark.read.csv(r"C:\Users\FindleyJD19\Downloads\proj2_data(1)\proj2_data\product_sample1.csv", header=True)
dfProducts = spark.read.csv(r"C:\Users\FindleyJD19\Downloads\proj2_data(1)\proj2_data\products1.csv", header=True)

df3 = dfProductSample.groupBy("productId").agg(sum("addToCartOrder").alias("numTimes")).select("productId","numTimes")

df4 = df3.join(dfProducts,on=["productId"],how="inner").select("productName","numTimes")

largest = df4.select(max(df4.numTimes).alias("numTimes"))

products = largest.join(df4,on=["numTimes"], how="inner").select("productName","numTimes").show()

spark.stop()