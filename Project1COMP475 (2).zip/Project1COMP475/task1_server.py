import socket, ssl

def main():
  context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
  context.load_cert_chain(certfile="server_crt.pem", keyfile="server_key.pem")
  context.load_verify_locations("ca_crt_crl.pem")
  
  bindsocket = socket.socket()
  bindsocket.bind(('', 9001))
  bindsocket.listen(5)

  newsocket, fromaddr = bindsocket.accept()
  connstream = context.wrap_socket(newsocket, server_side=True)
  
  try:  
    deal_with_client(connstream)       
  finally:
    connstream.shutdown(socket.SHUT_RDWR)
    connstream.close()

def do_something(connstream, data):
  if(data):  
    print("Client says: " + data)
    if(data == "done"):
      return False
  return True

def deal_with_client(connstream):
    print("\n")
    connstream.send("Hello Client!")  
    data = connstream.read()
    # null data means the client is finished with us
    while True:
      if not do_something(connstream, data):  
        break # finished with client  
      val = raw_input("Enter a message for Client: ") 
      connstream.send(val)  
      data = connstream.read()          
              
if __name__ == "__main__":
    main()