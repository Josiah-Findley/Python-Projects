import ssl, socket

def main():
    context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
    context.load_cert_chain(certfile="client_crt.pem", keyfile="client_key.pem")
    #context = ssl.SSLContext(ssl.PROTOCOL_TLS)
    context.verify_mode = ssl.CERT_REQUIRED
    context.set_ciphers("CAMELLIA128-SHA")
    context.check_hostname = True
    context.load_verify_locations("ca_crt.pem")
    connstream = context.wrap_socket(socket.socket(socket.AF_INET),
                                 server_hostname="cslnx114.gcc.edu")
    connstream.connect(("cslnx114.gcc.edu", 9001))

    try:  
      deal_with_server(connstream)       
    finally:
      connstream.shutdown(socket.SHUT_RDWR)
      connstream.close()
      
def do_something(connstream, data):
  if(data):  
    print("Server says: " + data)
  return True

def deal_with_server(connstream):
    print("\n")
    data = connstream.read()
    # null data means the client is finished with us
    while True:
      if not do_something(connstream, data):  
        break # finished with client 
      
      val = raw_input("Enter a message for Server: ") 
      connstream.send(val)
      if(val =="done"):
        break
      data = connstream.read()     
      

if __name__ == "__main__":
    main()